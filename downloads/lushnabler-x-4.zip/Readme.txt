Heya!
This is the Exitpass branch.

The goal here is to do a couple things.

Get Lushnabler away from being a 1.18 emulator as features are coming.
And work on gettings Lushnabler stable and efficient.